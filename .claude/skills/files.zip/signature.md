# 签名模板

## 必需标签（7 个）

| 标签 | 用途 | 要求 |
|------|------|------|
| `<role>` | 角色定义 | 专业身份 + 核心能力 + 知识背景 |
| `<goal>` | 任务目标 | 动作 + 对象 + 范围 + 输出物 |
| `<input>` | 输入说明 | 字段列表 + 必填/可选标注 |
| `<output_format>` | 输出格式 | 完整模板，代码块必须闭合 |
| `<constraints>` | 约束条件 | 数量 + 质量 + 格式约束 |
| `<error_handling>` | 异常处理 | ≥3 种异常情况及处理方式 |
| `<examples>` | 示例 | 完整输入 + 完整输出 |

## 格式规则

1. 每个 `<tag>` 必须有 `</tag>` 闭合
2. 所有 ``` 必须成对出现
3. 代码块必须在 `</output_format>` 前闭合
4. 禁止空表格行
5. 示例必须在 `<examples>` 内

---

## 完整模板

```xml
<role>
你是{expertise}专家。
- 核心能力：{abilities}
- 知识背景：{knowledge}
</role>

<goal>
{task_description}
- 覆盖范围：{scope}
- 输出物：{deliverables}
</goal>

<input>
请提供以下信息：
- {field1}：[说明]（必填）
- {field2}：[说明]（可选）
</input>

<output_format>
## {标题}

### {部分1}
| 列1 | 列2 | 列3 |
|-----|-----|-----|
| 值1 | 值2 | 值3 |

### {部分2}
```python
def example():
    pass
```
</output_format>

<constraints>
1. {数量约束}
2. {质量约束}
3. {格式约束}
</constraints>

<error_handling>
- 如果 {condition1}: {action1}
- 如果 {condition2}: {action2}
- 如果 {condition3}: {action3}
</error_handling>

<examples>
输入：
{example_input}

输出：
{example_output}
</examples>
```

---

## 生成检查清单

| # | 检查项 | 要求 |
|---|--------|------|
| 1 | 7 必需标签 | 全部存在且闭合 |
| 2 | ``` 配对 | 数量为偶数 |
| 3 | 空表格行 | 不存在 |
| 4 | 示例位置 | 在 `<examples>` 内 |
